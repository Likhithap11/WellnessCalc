
import React, { useState } from 'react';
import { Scale, Target, TrendingUp, User, Apple, Leaf, Sparkles } from 'lucide-react';

const BodyCompositionCalculator = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [neck, setNeck] = useState('');
  const [waist, setWaist] = useState('');
  const [hip, setHip] = useState('');
  const [gender, setGender] = useState('male');
  const [unit, setUnit] = useState('metric');
  const [result, setResult] = useState<any>(null);

  const calculateBodyComposition = () => {
    if (!weight || !height || !neck || !waist || (gender === 'female' && !hip)) return;

    let weightKg = parseFloat(weight);
    let heightIn = parseFloat(height);
    let neckIn = parseFloat(neck);
    let waistIn = parseFloat(waist);
    let hipIn = parseFloat(hip);

    // Convert to inches if metric
    if (unit === 'metric') {
      heightIn = heightIn / 2.54; // cm to inches
      neckIn = neckIn / 2.54;
      waistIn = waistIn / 2.54;
      if (gender === 'female') hipIn = hipIn / 2.54;
    } else {
      weightKg = weightKg * 0.453592; // lbs to kg
    }

    let bodyFatPercentage = 0;

    // U.S. Navy Formula
    if (gender === 'male') {
      bodyFatPercentage = 86.010 * Math.log10(waistIn - neckIn) - 70.041 * Math.log10(heightIn) + 36.76;
    } else {
      bodyFatPercentage = 163.205 * Math.log10(waistIn + hipIn - neckIn) - 97.684 * Math.log10(heightIn) - 78.387;
    }

    // Ensure valid range
    bodyFatPercentage = Math.max(3, Math.min(50, bodyFatPercentage));

    const fatMass = weightKg * (bodyFatPercentage / 100);
    const leanBodyMass = weightKg - fatMass;

    let category = '';
    let color = '';
    let foods = [];
    let meditations = [];
    let specialFeatures = [];
    const isMale = gender === 'male';

    if (isMale) {
      if (bodyFatPercentage <= 5) { 
        category = 'Essential Fat'; 
        color = 'text-blue-600';
        foods = [
          'High-calorie nutrient-dense foods',
          'Healthy fats (nuts, avocados, olive oil)',
          'Protein-rich foods for muscle building',
          'Complex carbohydrates for energy',
          'Frequent meals throughout the day'
        ];
      }
      else if (bodyFatPercentage <= 13) { 
        category = 'Athletes'; 
        color = 'text-green-600';
        foods = [
          'Performance-optimized nutrition',
          'Timing carbs around workouts',
          'High-quality protein sources',
          'Anti-inflammatory foods',
          'Strategic hydration and electrolytes'
        ];
      }
      else if (bodyFatPercentage <= 17) { 
        category = 'Fitness'; 
        color = 'text-emerald-600';
        foods = [
          'Balanced macronutrient distribution',
          'Lean proteins with each meal',
          'Whole food carbohydrates',
          'Moderate healthy fat intake',
          'Regular meal timing'
        ];
      }
      else if (bodyFatPercentage <= 24) { 
        category = 'Average'; 
        color = 'text-yellow-600';
        foods = [
          'Focus on portion control',
          'Increase vegetable intake',
          'Choose lean protein sources',
          'Limit processed foods',
          'Stay consistent with meal timing'
        ];
      }
      else { 
        category = 'Obese'; 
        color = 'text-red-600';
        foods = [
          'Calorie-controlled whole foods',
          'High-fiber, low-calorie vegetables',
          'Lean protein at every meal',
          'Limited refined carbohydrates',
          'Plenty of water and herbal teas'
        ];
      }
    } else {
      if (bodyFatPercentage <= 13) { 
        category = 'Essential Fat'; 
        color = 'text-blue-600';
        foods = [
          'Hormone-supporting healthy fats',
          'Iron-rich foods for energy',
          'Calcium and vitamin D sources',
          'Regular meals to support metabolism',
          'Nutrient-dense calorie additions'
        ];
      }
      else if (bodyFatPercentage <= 20) { 
        category = 'Athletes'; 
        color = 'text-green-600';
        foods = [
          'Performance nutrition for female athletes',
          'Iron-rich foods (lean meats, spinach)',
          'Calcium for bone health',
          'Strategic carb timing',
          'Adequate protein for recovery'
        ];
      }
      else if (bodyFatPercentage <= 24) { 
        category = 'Fitness'; 
        color = 'text-emerald-600';
        foods = [
          'Balanced approach to nutrition',
          'Regular protein intake',
          'Whole grains and vegetables',
          'Healthy fats for hormone balance',
          'Consistent eating patterns'
        ];
      }
      else if (bodyFatPercentage <= 31) { 
        category = 'Average'; 
        color = 'text-yellow-600';
        foods = [
          'Mindful portion sizes',
          'Increase fiber intake',
          'Choose quality proteins',
          'Reduce added sugars',
          'Focus on whole foods'
        ];
      }
      else { 
        category = 'Obese'; 
        color = 'text-red-600';
        foods = [
          'Structured meal planning',
          'High-volume, low-calorie foods',
          'Protein with every meal',
          'Limited processed foods',
          'Regular hydration schedule'
        ];
      }
    }

    // Universal meditations and features based on body composition goals
    if (bodyFatPercentage <= 13) {
      meditations = [
        'Body appreciation and gratitude meditation',
        'Performance visualization techniques',
        'Strength and confidence building',
        'Mind-muscle connection practices'
      ];
      specialFeatures = [
        '🏆 Elite performance tracking',
        '📊 Advanced body composition monitoring',
        '🎯 Precision nutrition planning',
        '💪 Strength optimization protocols'
      ];
    } else if (bodyFatPercentage <= 24) {
      meditations = [
        'Body positivity and self-acceptance',
        'Motivation for healthy lifestyle',
        'Stress management for weight control',
        'Mindful eating practices'
      ];
      specialFeatures = [
        '📈 Progress photo timeline',
        '🎯 Goal-setting and tracking',
        '💡 Habit formation guidance',
        '🏃 Activity level optimization'
      ];
    } else {
      meditations = [
        'Self-compassion and patience',
        'Emotional eating awareness',
        'Motivation and determination building',
        'Stress reduction for cortisol management'
      ];
      specialFeatures = [
        '🏥 Health professional referrals',
        '📋 Comprehensive meal planning',
        '💧 Hydration and habit tracking',
        '🤝 Support community access'
      ];
    }

    setResult({
      bodyFat: bodyFatPercentage.toFixed(1),
      fatMass: fatMass.toFixed(1),
      leanBodyMass: leanBodyMass.toFixed(1),
      category,
      color,
      foods,
      meditations,
      specialFeatures
    });
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <Target className="h-10 w-10 text-blue-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Body Composition Calculator</h2>
        <p className="text-gray-600">Estimate your body composition and get personalized nutrition guidance</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
            <div className="flex space-x-4">
              <button
                onClick={() => setGender('male')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  gender === 'male'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Male
              </button>
              <button
                onClick={() => setGender('female')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  gender === 'female'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Female
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Unit System</label>
            <div className="flex space-x-4">
              <button
                onClick={() => setUnit('metric')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  unit === 'metric'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Metric (cm, kg)
              </button>
              <button
                onClick={() => setUnit('imperial')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  unit === 'imperial'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Imperial (in, lbs)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Height ({unit === 'metric' ? 'cm' : 'in'})
              </label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={unit === 'metric' ? 'e.g., 175' : 'e.g., 69'}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Neck ({unit === 'metric' ? 'cm' : 'in'})
              </label>
              <input
                type="number"
                value={neck}
                onChange={(e) => setNeck(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={unit === 'metric' ? 'e.g., 38' : 'e.g., 15'}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Waist ({unit === 'metric' ? 'cm' : 'in'})
              </label>
              <input
                type="number"
                value={waist}
                onChange={(e) => setWaist(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={unit === 'metric' ? 'e.g., 85' : 'e.g., 33'}
              />
            </div>
          </div>

          {gender === 'female' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hip ({unit === 'metric' ? 'cm' : 'in'})
              </label>
              <input
                type="number"
                value={hip}
                onChange={(e) => setHip(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={unit === 'metric' ? 'e.g., 95' : 'e.g., 37'}
              />
            </div>
          )}

          <button
            onClick={calculateBodyComposition}
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <Target className="h-5 w-5" />
            <span>Calculate Body Composition</span>
          </button>
        </div>

        {/* Results */}
        <div className="space-y-6">
          {result ? (
            <>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">Body Composition Results</h3>
                  
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{result.bodyFat}%</div>
                      <div className="text-sm text-gray-600">Body Fat</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{result.leanBodyMass}kg</div>
                      <div className="text-sm text-gray-600">Lean Mass</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{result.fatMass}kg</div>
                      <div className="text-sm text-gray-600">Fat Mass</div>
                    </div>
                  </div>
                  
                  <div className={`text-xl font-semibold ${result.color}`}>{result.category}</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Apple className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Targeted Nutrition</h3>
                </div>
                <ul className="space-y-2">
                  {result.foods.map((food: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{food}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Leaf className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Body-Mind Meditations</h3>
                </div>
                <ul className="space-y-2">
                  {result.meditations.map((meditation: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{meditation}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 shadow-lg border border-blue-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Composition Tools</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.specialFeatures.map((feature: string, index: number) => (
                    <div key={index} className="bg-white p-3 rounded-lg shadow-sm border border-blue-100">
                      <span className="text-gray-700 text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <TrendingUp className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Body Fat Categories</h3>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Essential Fat:</span>
                    <span>{gender === 'male' ? '2-5%' : '10-13%'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Athletes:</span>
                    <span>{gender === 'male' ? '6-13%' : '14-20%'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Fitness:</span>
                    <span>{gender === 'male' ? '14-17%' : '21-24%'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average:</span>
                    <span>{gender === 'male' ? '18-24%' : '25-31%'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Obese:</span>
                    <span>{gender === 'male' ? '25%+' : '32%+'}</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-gray-50 rounded-2xl p-8 text-center">
              <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Enter your measurements to get personalized body composition guidance</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BodyCompositionCalculator;
