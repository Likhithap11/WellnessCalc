
import React, { useState } from 'react';
import { Brain, Heart, TrendingUp, Zap, Apple, Leaf, Sparkles } from 'lucide-react';

const StressLevelEstimator = () => {
  const [answers, setAnswers] = useState<number[]>(new Array(7).fill(-1));
  const [result, setResult] = useState<any>(null);

  const questions = [
    "How often do you feel overwhelmed or anxious?",
    "How well do you sleep at night?",
    "How often do you feel fatigued even after rest?",
    "Do you experience muscle tension, headaches, or stomach issues?",
    "How often do you feel impatient or irritable?",
    "How often do you find it hard to concentrate or focus?",
    "Do you feel a loss of control over your life or time?"
  ];

  const options = [
    { text: "Never", score: 0, color: "text-green-600" },
    { text: "Sometimes", score: 1, color: "text-yellow-600" },
    { text: "Often", score: 2, color: "text-orange-600" },
    { text: "Always", score: 3, color: "text-red-600" }
  ];

  const handleAnswerChange = (questionIndex: number, score: number) => {
    const newAnswers = [...answers];
    newAnswers[questionIndex] = score;
    setAnswers(newAnswers);
  };

  const calculateStress = () => {
    if (answers.includes(-1)) return;

    const totalScore = answers.reduce((sum, score) => sum + score, 0);
    
    let level = '';
    let color = '';
    let emoji = '';
    let recommendations = [];
    let description = '';
    let foods = [];
    let meditations = [];
    let specialFeatures = [];

    if (totalScore <= 6) {
      level = 'Low Stress';
      color = 'text-green-600';
      emoji = '😌';
      description = 'You seem to be managing stress well and maintaining good mental balance.';
      recommendations = [
        'Continue your current stress management practices',
        'Maintain regular exercise and healthy sleep habits',
        'Practice gratitude and mindfulness daily',
        'Keep up social connections and hobbies'
      ];
      foods = [
        'Brain-boosting foods (blueberries, walnuts, salmon)',
        'Complex carbohydrates for stable energy',
        'Magnesium-rich foods (leafy greens, almonds)',
        'Antioxidant-rich fruits and vegetables',
        'Herbal teas (chamomile, green tea)',
        'Regular, balanced meals'
      ];
      meditations = [
        'Gratitude meditation (5-10 minutes daily)',
        'Mindfulness practice for present moment awareness',
        'Body scan relaxation',
        'Loving-kindness meditation for positivity'
      ];
      specialFeatures = [
        '✨ Wellness maintenance tracker',
        '🌟 Positive habit reinforcement',
        '📊 Stress prevention insights',
        '🎯 Peak performance optimization'
      ];
    } else if (totalScore <= 12) {
      level = 'Moderate Stress';
      color = 'text-yellow-600';
      emoji = '😐';
      description = 'You may be experiencing some stress that could benefit from attention.';
      recommendations = [
        'Try deep breathing exercises or meditation',
        'Establish a regular sleep schedule',
        'Consider light exercise like walking or yoga',
        'Talk to friends, family, or a counselor'
      ];
      foods = [
        'Stress-reducing foods (dark chocolate, avocados)',
        'Omega-3 rich fish (salmon, mackerel)',
        'Complex carbs for serotonin production',
        'Probiotic foods for gut-brain health',
        'Limit caffeine and alcohol',
        'Stay hydrated with water and herbal teas'
      ];
      meditations = [
        'Deep breathing exercises (4-7-8 technique)',
        'Progressive muscle relaxation',
        'Mindful walking meditation',
        'Stress-release visualization'
      ];
      specialFeatures = [
        '⏰ Stress check-in reminders',
        '🧘 Quick relaxation techniques',
        '📱 Mood tracking and insights',
        '🎵 Personalized calming playlists'
      ];
    } else if (totalScore <= 17) {
      level = 'High Stress';
      color = 'text-orange-600';
      emoji = '😰';
      description = 'You appear to be under significant stress that may impact your well-being.';
      recommendations = [
        'Practice stress-reduction techniques daily',
        'Consider professional counseling or therapy',
        'Limit caffeine and alcohol consumption',
        'Prioritize self-care and relaxation time'
      ];
      foods = [
        'Anti-inflammatory foods (turmeric, ginger)',
        'Magnesium supplements or rich foods',
        'Vitamin B complex foods (whole grains)',
        'Calming herbal teas (valerian, passionflower)',
        'Avoid processed and high-sugar foods',
        'Regular meal timing for blood sugar stability'
      ];
      meditations = [
        'Extended meditation sessions (15-20 minutes)',
        'Anxiety-relief breathing techniques',
        'Body tension release practices',
        'Guided imagery for stress relief'
      ];
      specialFeatures = [
        '🆘 Crisis intervention resources',
        '📞 Professional help finder',
        '📚 Stress management course access',
        '🤝 Peer support group connections'
      ];
    } else {
      level = 'Critical Stress';
      color = 'text-red-600';
      emoji = '😵';
      description = 'You may be experiencing severe stress that requires immediate attention.';
      recommendations = [
        'Seek professional help from a healthcare provider',
        'Contact a mental health professional',
        'Reach out to trusted friends or family for support',
        'Consider calling a mental health hotline if needed'
      ];
      foods = [
        'Nutrient-dense, easy-to-prepare foods',
        'Anti-stress supplements (as recommended by doctor)',
        'Comfort foods in moderation',
        'Stay hydrated - dehydration worsens stress',
        'Avoid alcohol and excessive caffeine',
        'Consider meal delivery or support with nutrition'
      ];
      meditations = [
        'Emergency stress relief techniques',
        'Grounding exercises for panic management',
        'Self-compassion meditation',
        'Crisis-specific guided meditations'
      ];
      specialFeatures = [
        '🚨 Emergency contact system',
        '🏥 Immediate professional referrals',
        '📞 24/7 crisis helpline access',
        '🆘 Safety planning resources'
      ];
    }

    setResult({
      score: totalScore,
      level,
      color,
      emoji,
      description,
      recommendations,
      foods,
      meditations,
      specialFeatures
    });
  };

  const resetTest = () => {
    setAnswers(new Array(7).fill(-1));
    setResult(null);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <Brain className="h-10 w-10 text-purple-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Stress Level Estimator</h2>
        <p className="text-gray-600">Answer these questions to get personalized stress management recommendations</p>
      </div>

      {!result ? (
        <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200">
          <div className="space-y-8">
            {questions.map((question, questionIndex) => (
              <div key={questionIndex} className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-800">
                  {questionIndex + 1}. {question}
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {options.map((option, optionIndex) => (
                    <button
                      key={optionIndex}
                      onClick={() => handleAnswerChange(questionIndex, option.score)}
                      className={`p-3 rounded-lg border-2 transition-all duration-300 ${
                        answers[questionIndex] === option.score
                          ? `border-purple-500 bg-purple-50 ${option.color}`
                          : 'border-gray-200 hover:border-gray-300 text-gray-700'
                      }`}
                    >
                      {option.text}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <div className="flex justify-center pt-6">
              <button
                onClick={calculateStress}
                disabled={answers.includes(-1)}
                className={`px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2 ${
                  answers.includes(-1)
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
                }`}
              >
                <Zap className="h-5 w-5" />
                <span>Calculate Stress Level</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200">
            <div className="text-center">
              <div className="text-6xl mb-4">{result.emoji}</div>
              <h3 className="text-3xl font-bold text-gray-800 mb-2">Your Stress Level</h3>
              <div className={`text-2xl font-bold ${result.color} mb-2`}>{result.level}</div>
              <div className="text-lg text-gray-600 mb-4">Score: {result.score}/21</div>
              <p className="text-gray-700">{result.description}</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
            <div className="flex items-center space-x-2 mb-4">
              <Apple className="h-6 w-6 text-purple-600" />
              <h3 className="text-xl font-bold text-gray-800">Stress-Relief Nutrition</h3>
            </div>
            <ul className="space-y-2">
              {result.foods.map((food: string, index: number) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 text-sm">{food}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
            <div className="flex items-center space-x-2 mb-4">
              <Leaf className="h-6 w-6 text-purple-600" />
              <h3 className="text-xl font-bold text-gray-800">Stress-Management Meditations</h3>
            </div>
            <ul className="space-y-2">
              {result.meditations.map((meditation: string, index: number) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700 text-sm">{meditation}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 shadow-lg border border-purple-200">
            <div className="flex items-center space-x-2 mb-4">
              <Sparkles className="h-6 w-6 text-purple-600" />
              <h3 className="text-xl font-bold text-gray-800">Stress Support Tools</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {result.specialFeatures.map((feature: string, index: number) => (
                <div key={index} className="bg-white p-3 rounded-lg shadow-sm border border-purple-100">
                  <span className="text-gray-700 text-sm font-medium">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
            <div className="flex items-center space-x-2 mb-4">
              <Heart className="h-6 w-6 text-purple-600" />
              <h3 className="text-xl font-bold text-gray-800">General Recommendations</h3>
            </div>
            <ul className="space-y-3">
              {result.recommendations.map((rec: string, index: number) => (
                <li key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">{rec}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="text-center">
            <button
              onClick={resetTest}
              className="px-6 py-3 bg-gray-600 text-white rounded-lg font-semibold hover:bg-gray-700 transition-colors"
            >
              Take Test Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default StressLevelEstimator;
