
import React, { useState } from 'react';
import { Activity, Flame, Target, Apple, Leaf, Sparkles } from 'lucide-react';

const BMRCalculator = () => {
  const [formData, setFormData] = useState({
    age: '',
    gender: 'male',
    height: '',
    weight: '',
    unit: 'metric'
  });
  const [result, setResult] = useState<any>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const calculateBMR = () => {
    if (!formData.age || !formData.height || !formData.weight) return;

    let heightInCm = parseFloat(formData.height);
    let weightInKg = parseFloat(formData.weight);

    if (formData.unit === 'imperial') {
      heightInCm = heightInCm * 30.48; // feet to cm
      weightInKg = weightInKg * 0.453592; // pounds to kg
    }

    let bmr = 0;
    // Mifflin-St Jeor Equation
    if (formData.gender === 'male') {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * parseInt(formData.age) + 5;
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * parseInt(formData.age) - 161;
    }

    let foods = [];
    let meditations = [];
    let specialFeatures = [];

    if (formData.gender === 'male') {
      foods = [
        'High-protein breakfast (eggs, Greek yogurt, protein smoothie)',
        'Complex carbohydrates (oats, quinoa, sweet potatoes)',
        'Lean meats and fish (chicken, salmon, turkey)',
        'Nuts and seeds for healthy fats',
        'Pre and post-workout snacks',
        'Adequate hydration (8-10 glasses water daily)'
      ];
    } else {
      foods = [
        'Iron-rich foods (spinach, lean red meat, lentils)',
        'Calcium sources (dairy, leafy greens, almonds)',
        'Protein with every meal (fish, tofu, beans)',
        'Healthy fats (avocado, olive oil, nuts)',
        'Folate-rich foods (broccoli, asparagus, citrus)',
        'Regular meals to support hormone balance'
      ];
    }

    meditations = [
      'Morning energy activation meditation (5-10 min)',
      'Metabolism-boosting visualization',
      'Mindful eating to honor your BMR needs',
      'Evening relaxation for recovery',
      'Breath work for cellular energy'
    ];

    specialFeatures = [
      '🔥 Real-time calorie burn tracker',
      '⏰ Meal timing optimizer based on your BMR',
      '📊 Metabolic age calculator',
      '🎯 Personalized macro ratio recommendations',
      '💪 Strength training to boost BMR',
      '🧬 Genetic factors consideration guide'
    ];

    const recommendations = [
      `Your body burns ${Math.round(bmr)} calories at complete rest`,
      'This is the minimum energy needed for basic bodily functions',
      'Eating below this amount may slow your metabolism',
      'Use this as a baseline for your daily calorie needs',
      'Regular strength training can help increase your BMR'
    ];

    setResult({
      bmr: Math.round(bmr),
      recommendations,
      foods,
      meditations,
      specialFeatures
    });
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <Flame className="h-10 w-10 text-blue-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">BMR Calculator</h2>
        <p className="text-gray-600">Calculate your Basal Metabolic Rate and get personalized nutrition guidance</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Unit System
            </label>
            <div className="flex space-x-4">
              <button
                onClick={() => setFormData({...formData, unit: 'metric'})}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  formData.unit === 'metric'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Metric (cm, kg)
              </button>
              <button
                onClick={() => setFormData({...formData, unit: 'imperial'})}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  formData.unit === 'imperial'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Imperial (ft, lbs)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age (years)
              </label>
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="e.g., 30"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Gender
              </label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Height ({formData.unit === 'metric' ? 'cm' : 'feet'})
            </label>
            <input
              type="number"
              name="height"
              value={formData.height}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder={formData.unit === 'metric' ? 'e.g., 175' : 'e.g., 5.8'}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Weight ({formData.unit === 'metric' ? 'kg' : 'lbs'})
            </label>
            <input
              type="number"
              name="weight"
              value={formData.weight}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder={formData.unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
            />
          </div>

          <button
            onClick={calculateBMR}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <Activity className="h-5 w-5" />
            <span>Calculate BMR</span>
          </button>
        </div>

        {/* Results */}
        <div className="space-y-6">
          {result ? (
            <>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Your BMR</h3>
                  <div className="text-5xl font-bold text-blue-600 mb-2">{result.bmr}</div>
                  <div className="text-lg text-gray-600">calories per day</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Apple className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Metabolic Nutrition</h3>
                </div>
                <ul className="space-y-2">
                  {result.foods.map((food: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{food}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Leaf className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Energy Meditations</h3>
                </div>
                <ul className="space-y-2">
                  {result.meditations.map((meditation: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{meditation}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 shadow-lg border border-blue-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Metabolic Boosters</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.specialFeatures.map((feature: string, index: number) => (
                    <div key={index} className="bg-white p-3 rounded-lg shadow-sm border border-blue-100">
                      <span className="text-gray-700 text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Target className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-gray-800">Understanding Your BMR</h3>
                </div>
                <ul className="space-y-3">
                  {result.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="bg-gray-50 rounded-2xl p-8 text-center">
              <Flame className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Enter your details to get personalized metabolic recommendations</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BMRCalculator;
