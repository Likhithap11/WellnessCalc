
import React, { useState } from 'react';
import { Calculator, Scale, TrendingUp, Apple, Leaf, Sparkles } from 'lucide-react';

const BMICalculator = () => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [unit, setUnit] = useState('metric');
  const [result, setResult] = useState<any>(null);

  const calculateBMI = () => {
    if (!height || !weight) return;

    let heightInM = parseFloat(height);
    let weightInKg = parseFloat(weight);

    if (unit === 'imperial') {
      heightInM = heightInM * 0.3048; // feet to meters
      weightInKg = weightInKg * 0.453592; // pounds to kg
    } else {
      heightInM = heightInM / 100; // cm to meters
    }

    const bmi = weightInKg / (heightInM * heightInM);
    
    let category = '';
    let color = '';
    let recommendations = [];
    let foods = [];
    let meditations = [];
    let specialFeatures = [];

    if (bmi < 18.5) {
      category = 'Underweight';
      color = 'text-blue-600';
      recommendations = [
        'Consult with a healthcare provider',
        'Focus on nutrient-dense, calorie-rich foods',
        'Consider strength training to build muscle mass',
        'Eat frequent, balanced meals'
      ];
      foods = [
        'Nuts and nut butters (almonds, peanuts, cashews)',
        'Avocados and olive oil',
        'Whole grain breads and pasta',
        'Protein smoothies with banana and oats',
        'Greek yogurt with honey and granola',
        'Lean meats, fish, and eggs'
      ];
      meditations = [
        'Body positivity meditation (10-15 min)',
        'Mindful eating practices',
        'Confidence-building visualizations',
        'Stress-relief breathing exercises'
      ];
      specialFeatures = [
        '🎯 Personalized meal timing tracker',
        '💪 Progressive strength training plan',
        '📊 Weekly weight gain monitoring',
        '🧘 Daily affirmations for body acceptance'
      ];
    } else if (bmi >= 18.5 && bmi < 25) {
      category = 'Normal weight';
      color = 'text-green-600';
      recommendations = [
        'Maintain your current healthy weight',
        'Continue regular physical activity',
        'Eat a balanced diet with variety',
        'Stay hydrated and get adequate sleep'
      ];
      foods = [
        'Colorful vegetables (spinach, bell peppers, carrots)',
        'Lean proteins (chicken, fish, tofu, legumes)',
        'Whole grains (quinoa, brown rice, oats)',
        'Fresh fruits (berries, apples, citrus)',
        'Healthy fats (olive oil, nuts, seeds)',
        'Low-fat dairy or plant alternatives'
      ];
      meditations = [
        'Gratitude meditation (5-10 min)',
        'Mindfulness body scan',
        'Walking meditation in nature',
        'Loving-kindness meditation'
      ];
      specialFeatures = [
        '✨ Wellness streak tracker',
        '🌟 Habit formation coach',
        '🎨 Mood-based recipe suggestions',
        '🏃 Activity variety recommendations'
      ];
    } else if (bmi >= 25 && bmi < 30) {
      category = 'Overweight';
      color = 'text-yellow-600';
      recommendations = [
        'Aim for gradual weight loss (1-2 lbs per week)',
        'Increase physical activity to 150+ minutes/week',
        'Focus on portion control and balanced meals',
        'Consider consulting a nutritionist'
      ];
      foods = [
        'High-fiber vegetables (broccoli, Brussels sprouts)',
        'Lean proteins (grilled chicken, fish, legumes)',
        'Complex carbs in moderation (sweet potato, quinoa)',
        'Low-calorie fruits (berries, watermelon, grapefruit)',
        'Green tea and herbal teas',
        'Portion-controlled nuts and seeds'
      ];
      meditations = [
        'Mindful eating meditation before meals',
        'Stress-reduction breathing (when craving)',
        'Self-compassion meditation',
        'Goal visualization exercises'
      ];
      specialFeatures = [
        '📱 Smart portion size guide',
        '⏰ Intermittent fasting timer',
        '🎯 Weekly mini-goals system',
        '📸 Progress photo tracker with privacy'
      ];
    } else {
      category = 'Obese';
      color = 'text-red-600';
      recommendations = [
        'Consult with healthcare professionals',
        'Create a structured weight loss plan',
        'Start with low-impact exercises',
        'Consider professional nutritional guidance'
      ];
      foods = [
        'Non-starchy vegetables (unlimited quantities)',
        'Lean proteins (fish, chicken breast, tofu)',
        'Limited whole grains (1/2 cup portions)',
        'Low-sugar fruits (berries, green apples)',
        'Plenty of water and herbal teas',
        'Avoid processed foods and sugary drinks'
      ];
      meditations = [
        'Self-compassion and forgiveness meditation',
        'Emotional eating awareness practice',
        'Motivation and determination visualization',
        'Stress management breathing techniques'
      ];
      specialFeatures = [
        '🏥 Healthcare provider referral system',
        '📋 Meal planning assistant',
        '💧 Hydration reminder system',
        '🤝 Support community access'
      ];
    }

    setResult({
      bmi: bmi.toFixed(1),
      category,
      color,
      recommendations,
      foods,
      meditations,
      specialFeatures
    });
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-gradient-to-br from-emerald-100 to-emerald-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <Scale className="h-10 w-10 text-emerald-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">BMI Calculator</h2>
        <p className="text-gray-600">Calculate your Body Mass Index and get personalized wellness recommendations</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Unit System
            </label>
            <div className="flex space-x-4">
              <button
                onClick={() => setUnit('metric')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  unit === 'metric'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Metric (cm, kg)
              </button>
              <button
                onClick={() => setUnit('imperial')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  unit === 'imperial'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Imperial (ft, lbs)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Height ({unit === 'metric' ? 'cm' : 'feet'})
            </label>
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              placeholder={unit === 'metric' ? 'e.g., 175' : 'e.g., 5.8'}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Weight ({unit === 'metric' ? 'kg' : 'lbs'})
            </label>
            <input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              placeholder={unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
            />
          </div>

          <button
            onClick={calculateBMI}
            className="w-full bg-gradient-to-r from-emerald-600 to-green-600 text-white py-3 rounded-lg font-semibold hover:from-emerald-700 hover:to-green-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <Calculator className="h-5 w-5" />
            <span>Calculate BMI</span>
          </button>
        </div>

        {/* Results */}
        <div className="space-y-6">
          {result ? (
            <>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Your BMI</h3>
                  <div className="text-5xl font-bold text-emerald-600 mb-2">{result.bmi}</div>
                  <div className={`text-xl font-semibold ${result.color}`}>{result.category}</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Apple className="h-6 w-6 text-emerald-600" />
                  <h3 className="text-xl font-bold text-gray-800">Recommended Foods</h3>
                </div>
                <ul className="space-y-2">
                  {result.foods.map((food: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{food}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Leaf className="h-6 w-6 text-emerald-600" />
                  <h3 className="text-xl font-bold text-gray-800">Meditation Practices</h3>
                </div>
                <ul className="space-y-2">
                  {result.meditations.map((meditation: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{meditation}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl p-6 shadow-lg border border-emerald-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="h-6 w-6 text-emerald-600" />
                  <h3 className="text-xl font-bold text-gray-800">Special Features for You</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.specialFeatures.map((feature: string, index: number) => (
                    <div key={index} className="bg-white p-3 rounded-lg shadow-sm border border-emerald-100">
                      <span className="text-gray-700 text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <TrendingUp className="h-6 w-6 text-emerald-600" />
                  <h3 className="text-xl font-bold text-gray-800">General Recommendations</h3>
                </div>
                <ul className="space-y-3">
                  {result.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-emerald-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="bg-gray-50 rounded-2xl p-8 text-center">
              <Scale className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Enter your height and weight to get personalized wellness recommendations</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BMICalculator;
