
import React, { useState } from 'react';
import { TrendingUp, Target, Zap, Apple, Leaf, Sparkles } from 'lucide-react';

const TDEECalculator = () => {
  const [formData, setFormData] = useState({
    age: '',
    gender: 'male',
    height: '',
    weight: '',
    activity: 'sedentary',
    unit: 'metric'
  });
  const [result, setResult] = useState<any>(null);

  const activityLevels = {
    sedentary: { multiplier: 1.2, label: 'Sedentary (little or no exercise)' },
    light: { multiplier: 1.375, label: 'Light (light exercise 1-3 days/week)' },
    moderate: { multiplier: 1.55, label: 'Moderate (moderate exercise 3-5 days/week)' },
    active: { multiplier: 1.725, label: 'Active (hard exercise 6-7 days/week)' },
    veryActive: { multiplier: 1.9, label: 'Very Active (very hard exercise, physical job)' }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const calculateTDEE = () => {
    if (!formData.age || !formData.height || !formData.weight) return;

    let heightInCm = parseFloat(formData.height);
    let weightInKg = parseFloat(formData.weight);

    if (formData.unit === 'imperial') {
      heightInCm = heightInCm * 30.48; // feet to cm
      weightInKg = weightInKg * 0.453592; // pounds to kg
    }

    // Calculate BMR first (Mifflin-St Jeor Equation)
    let bmr = 0;
    if (formData.gender === 'male') {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * parseInt(formData.age) + 5;
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * parseInt(formData.age) - 161;
    }

    // Calculate TDEE
    const tdee = bmr * activityLevels[formData.activity as keyof typeof activityLevels].multiplier;

    // Calculate calorie recommendations for different goals
    const maintain = Math.round(tdee);
    const mildWeightLoss = Math.round(tdee - 250); // 0.5 lb/week loss
    const weightLoss = Math.round(tdee - 500); // 1 lb/week loss
    const mildWeightGain = Math.round(tdee + 250); // 0.5 lb/week gain
    const weightGain = Math.round(tdee + 500); // 1 lb/week gain

    // Activity-specific recommendations
    let foods = [];
    let meditations = [];
    let specialFeatures = [];

    if (formData.activity === 'sedentary') {
      foods = [
        'Light, frequent meals to boost metabolism',
        'High-fiber foods (vegetables, fruits, whole grains)',
        'Lean proteins to maintain muscle mass',
        'Green tea and metabolism-boosting spices',
        'Avoid heavy, processed foods',
        'Stay hydrated with water and herbal teas'
      ];
      meditations = [
        'Desk meditation breaks (2-3 min)',
        'Movement mindfulness practices',
        'Energy activation breathing',
        'Motivation meditation for activity'
      ];
      specialFeatures = [
        '⏰ Hourly movement reminders',
        '🚶 Step count integration',
        '🧘 Desk yoga routines',
        '💡 Energy-boosting tips'
      ];
    } else if (formData.activity === 'light' || formData.activity === 'moderate') {
      foods = [
        'Pre-workout: Banana with almond butter',
        'Post-workout: Protein smoothie with berries',
        'Complex carbs for sustained energy',
        'Lean proteins for muscle recovery',
        'Anti-inflammatory foods (salmon, walnuts)',
        'Proper hydration before, during, after exercise'
      ];
      meditations = [
        'Pre-workout focus meditation',
        'Post-workout recovery meditation',
        'Mindful movement practices',
        'Performance visualization'
      ];
      specialFeatures = [
        '🏃 Workout intensity tracker',
        '⚡ Recovery time optimizer',
        '📈 Progress milestone tracker',
        '🎯 Goal achievement rewards'
      ];
    } else {
      foods = [
        'High-calorie nutrient-dense foods',
        'Multiple protein sources throughout day',
        'Complex carbs for glycogen replenishment',
        'Healthy fats for hormone production',
        'Electrolyte-rich foods and drinks',
        'Strategic meal timing around workouts'
      ];
      meditations = [
        'Athletic performance visualization',
        'Mental toughness meditation',
        'Competition anxiety management',
        'Recovery and healing meditation'
      ];
      specialFeatures = [
        '🏆 Performance analytics dashboard',
        '⚡ Energy system optimization',
        '🔄 Advanced recovery tracking',
        '🎯 Competition preparation tools'
      ];
    }

    setResult({
      tdee: maintain,
      bmr: Math.round(bmr),
      goals: {
        maintain,
        mildWeightLoss,
        weightLoss,
        mildWeightGain,
        weightGain
      },
      activityLevel: activityLevels[formData.activity as keyof typeof activityLevels].label,
      foods,
      meditations,
      specialFeatures
    });
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-gradient-to-br from-cyan-100 to-cyan-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
          <Zap className="h-10 w-10 text-cyan-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">TDEE Calculator</h2>
        <p className="text-gray-600">Calculate your Total Daily Energy Expenditure and get activity-specific recommendations</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Unit System
            </label>
            <div className="flex space-x-4">
              <button
                onClick={() => setFormData({...formData, unit: 'metric'})}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  formData.unit === 'metric'
                    ? 'bg-cyan-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Metric (cm, kg)
              </button>
              <button
                onClick={() => setFormData({...formData, unit: 'imperial'})}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  formData.unit === 'imperial'
                    ? 'bg-cyan-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Imperial (ft, lbs)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age (years)
              </label>
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                placeholder="e.g., 30"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Gender
              </label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Height ({formData.unit === 'metric' ? 'cm' : 'feet'})
            </label>
            <input
              type="number"
              name="height"
              value={formData.height}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              placeholder={formData.unit === 'metric' ? 'e.g., 175' : 'e.g., 5.8'}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Weight ({formData.unit === 'metric' ? 'kg' : 'lbs'})
            </label>
            <input
              type="number"
              name="weight"
              value={formData.weight}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
              placeholder={formData.unit === 'metric' ? 'e.g., 70' : 'e.g., 154'}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Activity Level
            </label>
            <select
              name="activity"
              value={formData.activity}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
            >
              {Object.entries(activityLevels).map(([key, value]) => (
                <option key={key} value={key}>{value.label}</option>
              ))}
            </select>
          </div>

          <button
            onClick={calculateTDEE}
            className="w-full bg-gradient-to-r from-cyan-600 to-teal-600 text-white py-3 rounded-lg font-semibold hover:from-cyan-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2"
          >
            <TrendingUp className="h-5 w-5" />
            <span>Calculate TDEE</span>
          </button>
        </div>

        {/* Results */}
        <div className="space-y-6">
          {result ? (
            <>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="text-center mb-4">
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">Your TDEE</h3>
                  <div className="text-5xl font-bold text-cyan-600 mb-2">{result.tdee}</div>
                  <div className="text-lg text-gray-600">calories per day</div>
                  <div className="text-sm text-gray-500 mt-2">{result.activityLevel}</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Apple className="h-6 w-6 text-cyan-600" />
                  <h3 className="text-xl font-bold text-gray-800">Activity-Based Nutrition</h3>
                </div>
                <ul className="space-y-2">
                  {result.foods.map((food: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-cyan-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{food}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Leaf className="h-6 w-6 text-cyan-600" />
                  <h3 className="text-xl font-bold text-gray-800">Performance Meditations</h3>
                </div>
                <ul className="space-y-2">
                  {result.meditations.map((meditation: string, index: number) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-cyan-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700 text-sm">{meditation}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-br from-cyan-50 to-teal-50 rounded-2xl p-6 shadow-lg border border-cyan-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="h-6 w-6 text-cyan-600" />
                  <h3 className="text-xl font-bold text-gray-800">Smart Features</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {result.specialFeatures.map((feature: string, index: number) => (
                    <div key={index} className="bg-white p-3 rounded-lg shadow-sm border border-cyan-100">
                      <span className="text-gray-700 text-sm font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Target className="h-6 w-6 text-cyan-600" />
                  <h3 className="text-xl font-bold text-gray-800">Calorie Recommendations</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <span className="font-medium text-gray-700">Weight Loss (1 lb/week)</span>
                    <span className="font-bold text-red-600">{result.goals.weightLoss} cal/day</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                    <span className="font-medium text-gray-700">Mild Weight Loss (0.5 lb/week)</span>
                    <span className="font-bold text-orange-600">{result.goals.mildWeightLoss} cal/day</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="font-medium text-gray-700">Maintain Weight</span>
                    <span className="font-bold text-green-600">{result.goals.maintain} cal/day</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <span className="font-medium text-gray-700">Mild Weight Gain (0.5 lb/week)</span>
                    <span className="font-bold text-blue-600">{result.goals.mildWeightGain} cal/day</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                    <span className="font-medium text-gray-700">Weight Gain (1 lb/week)</span>
                    <span className="font-bold text-purple-600">{result.goals.weightGain} cal/day</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-gray-50 rounded-2xl p-8 text-center">
              <Zap className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Enter your details to get personalized activity recommendations</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TDEECalculator;
