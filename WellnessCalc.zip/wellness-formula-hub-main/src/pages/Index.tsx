
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Activity, Target, TrendingUp, Users, Award } from 'lucide-react';
import LoginModal from '../components/LoginModal';
import RegisterModal from '../components/RegisterModal';

const Index = () => {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      navigate('/dashboard');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-emerald-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                WellnessCalc
              </h1>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowLogin(true)}
                className="px-4 py-2 text-emerald-600 hover:text-emerald-700 font-medium transition-colors"
              >
                Login
              </button>
              <button
                onClick={() => setShowRegister(true)}
                className="px-6 py-2 bg-gradient-to-r from-emerald-600 to-blue-600 text-white rounded-lg hover:from-emerald-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                Register
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-emerald-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent mb-6">
            WellnessCalc
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto">
            Your personal health companion for calculating BMI, BMR, and TDEE with personalized recommendations
          </p>

          {/* Health Journey Diagram */}
          <div className="grid md:grid-cols-3 gap-8 mt-16 max-w-5xl mx-auto">
            <div className="bg-white/70 backdrop-blur-md rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-gradient-to-br from-emerald-100 to-emerald-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <Activity className="h-10 w-10 text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Calculate BMI</h3>
              <p className="text-gray-600">
                Determine your Body Mass Index to understand your weight status and health category
              </p>
            </div>

            <div className="bg-white/70 backdrop-blur-md rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <Target className="h-10 w-10 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Find Your BMR</h3>
              <p className="text-gray-600">
                Calculate your Basal Metabolic Rate to know how many calories your body burns at rest
              </p>
            </div>

            <div className="bg-white/70 backdrop-blur-md rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="bg-gradient-to-br from-cyan-100 to-cyan-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="h-10 w-10 text-cyan-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Get TDEE</h3>
              <p className="text-gray-600">
                Discover your Total Daily Energy Expenditure for personalized calorie recommendations
              </p>
            </div>
          </div>

          {/* Health Flow Diagram */}
          <div className="mt-20 bg-white/70 backdrop-blur-md rounded-3xl p-12 shadow-2xl max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-12">Your Health Journey</h2>
            <div className="flex flex-col md:flex-row items-center justify-between space-y-8 md:space-y-0 md:space-x-8">
              <div className="flex flex-col items-center">
                <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800">Join Us</h3>
                <p className="text-sm text-gray-600 text-center">Create your account</p>
              </div>
              
              <div className="hidden md:block w-16 h-0.5 bg-gradient-to-r from-emerald-500 to-blue-500"></div>
              
              <div className="flex flex-col items-center">
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <Activity className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800">Calculate</h3>
                <p className="text-sm text-gray-600 text-center">Use our health tools</p>
              </div>
              
              <div className="hidden md:block w-16 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500"></div>
              
              <div className="flex flex-col items-center">
                <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                  <Award className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800">Achieve</h3>
                <p className="text-sm text-gray-600 text-center">Reach your goals</p>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="mt-16 flex flex-col sm:flex-row gap-6 justify-center">
            <button
              onClick={() => setShowRegister(true)}
              className="px-8 py-4 bg-gradient-to-r from-emerald-600 to-blue-600 text-white text-lg font-semibold rounded-xl hover:from-emerald-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-xl"
            >
              Start Your Journey
            </button>
            <button
              onClick={() => setShowLogin(true)}
              className="px-8 py-4 border-2 border-emerald-600 text-emerald-600 text-lg font-semibold rounded-xl hover:bg-emerald-600 hover:text-white transition-all duration-300 transform hover:scale-105"
            >
              Already a Member?
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/90 backdrop-blur-md border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Heart className="h-6 w-6 text-emerald-600" />
              <span className="text-xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                WellnessCalc
              </span>
            </div>
            <p className="text-gray-600">© 2024 WellnessCalc. Your health, calculated perfectly.</p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <LoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
      <RegisterModal isOpen={showRegister} onClose={() => setShowRegister(false)} />
    </div>
  );
};

export default Index;
