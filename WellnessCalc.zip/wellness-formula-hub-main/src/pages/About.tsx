
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, LogOut, User, Menu, X, Activity, Target, TrendingUp, BookOpen, Users, Award } from 'lucide-react';

const About = () => {
  const [user, setUser] = useState<any>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/');
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-emerald-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                WellnessCalc
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-700 font-medium"
              >
                Dashboard
              </button>
              <button
                onClick={() => navigate('/about')}
                className="text-emerald-600 hover:text-emerald-700 font-medium"
              >
                About
              </button>
              <button
                onClick={() => navigate('/contact')}
                className="text-gray-600 hover:text-gray-700 font-medium"
              >
                Contact
              </button>
            </nav>

            {/* User Menu */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-600" />
                <span className="text-gray-700 font-medium">{user.name}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:text-red-700 font-medium transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-gray-600"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white border-t border-gray-200 py-4">
              <div className="flex flex-col space-y-4">
                <button
                  onClick={() => { navigate('/dashboard'); setIsMobileMenuOpen(false); }}
                  className="text-left text-gray-600 hover:text-gray-700 font-medium"
                >
                  Dashboard
                </button>
                <button
                  onClick={() => { navigate('/about'); setIsMobileMenuOpen(false); }}
                  className="text-left text-emerald-600 hover:text-emerald-700 font-medium"
                >
                  About
                </button>
                <button
                  onClick={() => { navigate('/contact'); setIsMobileMenuOpen(false); }}
                  className="text-left text-gray-600 hover:text-gray-700 font-medium"
                >
                  Contact
                </button>
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex items-center space-x-2 mb-4">
                    <User className="h-5 w-5 text-gray-600" />
                    <span className="text-gray-700 font-medium">{user.name}</span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 text-red-600 hover:text-red-700 font-medium"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-white/70 backdrop-blur-md rounded-3xl p-8 shadow-xl mb-8 text-center">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-4">
            About WellnessCalc
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your trusted companion for health calculations and personalized wellness recommendations
          </p>
        </div>

        {/* Mission Section */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white/70 backdrop-blur-md rounded-2xl p-8 shadow-xl">
            <div className="bg-gradient-to-br from-emerald-100 to-emerald-200 rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Target className="h-8 w-8 text-emerald-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Mission</h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              At WellnessCalc, we believe that understanding your body's metrics is the first step towards a healthier lifestyle. 
              Our mission is to provide accurate, science-based health calculations that empower you to make informed decisions 
              about your wellness journey.
            </p>
          </div>

          <div className="bg-white/70 backdrop-blur-md rounded-2xl p-8 shadow-xl">
            <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Users className="h-8 w-8 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Who We Serve</h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              Whether you're a fitness beginner taking your first steps towards health, someone on a weight management journey, 
              or a health-conscious individual tracking your metrics, WellnessCalc is designed for people who want to take 
              control of their health with reliable, easy-to-understand calculations.
            </p>
          </div>
        </div>

        {/* Features Section */}
        <div className="bg-white/70 backdrop-blur-md rounded-3xl p-8 shadow-xl mb-12">
          <h2 className="text-4xl font-bold text-center bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-12">
            Our Health Calculators
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <Activity className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">BMI Calculator</h3>
              <p className="text-gray-600 leading-relaxed">
                <strong>Body Mass Index (BMI)</strong> is a measure of body fat based on height and weight. 
                It helps categorize your weight status (underweight, normal, overweight, or obese) and assess 
                potential health risks. Our calculator uses the standard WHO formula: BMI = weight(kg) / height(m)².
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <Target className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">BMR Calculator</h3>
              <p className="text-gray-600 leading-relaxed">
                <strong>Basal Metabolic Rate (BMR)</strong> represents the number of calories your body needs 
                to maintain basic physiological functions at rest. We use the Mifflin-St Jeor equation, 
                considered the most accurate for calculating BMR based on age, gender, height, and weight.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">TDEE Calculator</h3>
              <p className="text-gray-600 leading-relaxed">
                <strong>Total Daily Energy Expenditure (TDEE)</strong> is your BMR multiplied by an activity factor. 
                It represents the total calories you burn in a day, including exercise and daily activities. 
                This helps determine your caloric needs for weight maintenance, loss, or gain.
              </p>
            </div>
          </div>
        </div>

        {/* Science Section */}
        <div className="bg-white/70 backdrop-blur-md rounded-3xl p-8 shadow-xl mb-12">
          <div className="text-center mb-12">
            <div className="bg-gradient-to-br from-purple-100 to-purple-200 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
              <BookOpen className="h-10 w-10 text-purple-600" />
            </div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-4">
              Backed by Science
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              All our calculations are based on peer-reviewed research and established medical standards
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Accurate Formulas</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-emerald-600 mt-1 mr-3 flex-shrink-0" />
                  <span>BMI calculations follow WHO international standards</span>
                </li>
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-emerald-600 mt-1 mr-3 flex-shrink-0" />
                  <span>BMR uses the Mifflin-St Jeor equation (most accurate)</span>
                </li>
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-emerald-600 mt-1 mr-3 flex-shrink-0" />
                  <span>TDEE incorporates validated activity multipliers</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Personalized Recommendations</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Calorie recommendations based on your specific goals</span>
                </li>
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Health categories aligned with medical guidelines</span>
                </li>
                <li className="flex items-start">
                  <Award className="h-5 w-5 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                  <span>Evidence-based weight management suggestions</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-3xl p-8 shadow-xl text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Health Journey?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Use our calculators to understand your body better and make informed health decisions
          </p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-8 py-4 bg-white text-emerald-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Go to Dashboard
          </button>
        </div>
      </main>
    </div>
  );
};

export default About;
