import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calculator, Activity, Target, TrendingUp, LogOut, Heart, User, Menu, X, Brain } from 'lucide-react';
import BMICalculator from '../components/BMICalculator';
import BMRCalculator from '../components/BMRCalculator';
import TDEECalculator from '../components/TDEECalculator';
import BodyCompositionCalculator from '../components/BodyCompositionCalculator';
import StressLevelEstimator from '../components/StressLevelEstimator';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('bmi');
  const [user, setUser] = useState<any>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/');
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/');
  };

  const tabs = [
    { id: 'bmi', label: 'BMI Calculator', icon: Calculator, color: 'emerald' },
    { id: 'bmr', label: 'BMR Calculator', icon: Activity, color: 'blue' },
    { id: 'tdee', label: 'TDEE Calculator', icon: TrendingUp, color: 'cyan' },
    { id: 'body-composition', label: 'Body Composition', icon: Target, color: 'indigo' },
    { id: 'stress-level', label: 'Stress Level', icon: Brain, color: 'purple' }
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-emerald-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                WellnessCalc
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-emerald-600 hover:text-emerald-700 font-medium"
              >
                Dashboard
              </button>
              <button
                onClick={() => navigate('/about')}
                className="text-gray-600 hover:text-gray-700 font-medium"
              >
                About
              </button>
              <button
                onClick={() => navigate('/contact')}
                className="text-gray-600 hover:text-gray-700 font-medium"
              >
                Contact
              </button>
            </nav>

            {/* User Menu */}
            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-600" />
                <span className="text-gray-700 font-medium">{user.name}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:text-red-700 font-medium transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden text-gray-600"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white border-t border-gray-200 py-4">
              <div className="flex flex-col space-y-4">
                <button
                  onClick={() => { navigate('/dashboard'); setIsMobileMenuOpen(false); }}
                  className="text-left text-emerald-600 hover:text-emerald-700 font-medium"
                >
                  Dashboard
                </button>
                <button
                  onClick={() => { navigate('/about'); setIsMobileMenuOpen(false); }}
                  className="text-left text-gray-600 hover:text-gray-700 font-medium"
                >
                  About
                </button>
                <button
                  onClick={() => { navigate('/contact'); setIsMobileMenuOpen(false); }}
                  className="text-left text-gray-600 hover:text-gray-700 font-medium"
                >
                  Contact
                </button>
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex items-center space-x-2 mb-4">
                    <User className="h-5 w-5 text-gray-600" />
                    <span className="text-gray-700 font-medium">{user.name}</span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="flex items-center space-x-2 text-red-600 hover:text-red-700 font-medium"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-white/70 backdrop-blur-md rounded-3xl p-8 shadow-xl mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent mb-2">
            Welcome back, {user.name}!
          </h1>
          <p className="text-gray-600 text-lg">
            Ready to track your health metrics? Choose a calculator below to get started.
          </p>
        </div>

        {/* Calculator Tabs */}
        <div className="bg-white/70 backdrop-blur-md rounded-3xl shadow-xl overflow-hidden">
          {/* Tab Navigation */}
          <div className="border-b border-gray-200">
            <nav className="flex flex-col sm:flex-row overflow-x-auto">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 px-4 py-4 font-medium transition-all duration-300 whitespace-nowrap ${
                      activeTab === tab.id
                        ? `text-${tab.color}-600 border-b-2 border-${tab.color}-600 bg-${tab.color}-50`
                        : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-sm">{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-8">
            {activeTab === 'bmi' && <BMICalculator />}
            {activeTab === 'bmr' && <BMRCalculator />}
            {activeTab === 'tdee' && <TDEECalculator />}
            {activeTab === 'body-composition' && <BodyCompositionCalculator />}
            {activeTab === 'stress-level' && <StressLevelEstimator />}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
